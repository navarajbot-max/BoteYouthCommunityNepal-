================================================================================
BOTE YOUTH COMMUNITY NEPAL - BLOGGER THEME PACKAGE (v3.0.0)
================================================================================
Theme Name: Bote Youth Community Nepal - Official Portal & Community Matrix
Version: 3.0.0 (Blogger v3.xml)
Author: Bote Youth Community Nepal (BYCN)
Headquarters: Ward No. 11, Karmaiya, Bagmati Municipality, Sarlahi District, Nepal
Website: https://boteyouthcommunity.org.np/
================================================================================

PACKAGE CONTENTS:
1. Bote-Youth-Community-Nepal-Blogger-Theme-v3.xml
   - The primary Blogger Theme file with all working features:
     * Google Search Console Verification Meta Tag pre-installed in <head>
     * Executive Officers Leadership Roster (10 widgets: Chair, Vice-Chair, Gen Sec, Treasurer, etc.)
     * Online Membership Registration & Digital ID Card Generator
     * Educational Scholarship Desk Form
     * Live Community Voice Voting Poll
     * In-Browser Website Control Center (Settings button ⚙)
     * Responsive Bento Grid Heritage Matrix & Lexicon Showcase

2. HOW-TO-INSTALL-IN-BLOGGER.txt
   - Step-by-step restore and HTML installation guide for Blogger.com.

3. GOOGLE-SEARCH-CONSOLE-SETUP.txt
   - How to verify site ownership in Google Search Console.

================================================================================
QUICK INSTALLATION IN BLOGGER (2 STEPS):
================================================================================
1. Go to https://www.blogger.com and log in.
2. In the left menu, click 'Theme'.
3. Click the downward arrow next to the orange 'Customize' button.
4. Select 'Restore' -> click 'Upload'.
5. Choose 'Bote-Youth-Community-Nepal-Blogger-Theme-v3.xml' from this ZIP folder.
6. Blogger will display 'Theme restored'. Visit your blog URL to see the live site!

================================================================================
GOOGLE SEARCH CONSOLE VERIFICATION:
================================================================================
Your site verification code is pre-embedded inside the <head> tag:
<meta name="google-site-verification" content="ZZ8jKxT9NeljW8zcOXO1HjIn5-weF8pC0qVd4hsZoEw"/>

Once this theme is installed on your blog:
1. Open https://search.google.com/search-console
2. Enter your blog URL (e.g., yourname.blogspot.com)
3. Choose 'HTML tag' verification method.
4. Click 'Verify'.
================================================================================